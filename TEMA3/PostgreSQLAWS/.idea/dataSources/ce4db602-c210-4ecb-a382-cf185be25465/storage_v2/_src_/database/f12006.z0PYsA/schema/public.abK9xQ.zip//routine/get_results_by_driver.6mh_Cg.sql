create function get_results_by_driver(driver_code character varying)
    returns TABLE(round integer, circuit character varying, result integer, points integer, date date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT ra.round, ra.name, re.position, re.points, ra.date
    FROM drivers d 
	LEFT JOIN results re ON d.driverid = re.driverid
    JOIN races ra ON re.raceid = ra.raceid
    WHERE d.code = driver_code;
END;
$$;

alter function get_results_by_driver(varchar) owner to postgres;

