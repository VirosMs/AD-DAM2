create function get_drivers_standings()
    returns TABLE(driver text, points bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT CONCAT_WS(' ', d.forename, d.surname), SUM(r.points)
    FROM drivers d 
	LEFT JOIN results r ON d.driverid = r.driverid
    GROUP BY d.driverid
	ORDER BY SUM(r.points) DESC;
END;
$$;

alter function get_drivers_standings() owner to postgres;

